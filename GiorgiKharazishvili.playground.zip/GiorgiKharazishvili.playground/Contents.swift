import UIKit

var greeting = "Hello, playground"

//1. გვაქვს 1,5,10,20 და 50 თეთრიანი მონეტები. დაწერეთ ფუნქცია, რომელსაც გადაეცემა თანხა (თეთრებში) და აბრუნებს მონეტების მინიმალურ რაოდენობას, რომლითაც შეგვიძლია ეს თანხა დავახურდაოთ.

func minSplit(startAmount: Int) -> Int {
    let coins = [1, 5, 10, 20, 50]
    //  რა თქმა უნდა შეგვეძლო საწინააღმდეგო თანმიმდევრობით ჩაგვეწერა მასივი
    //  let coins = [50, 20, 10, 5, 1]
    
    var count = 0
    var remainingAmount = startAmount
    for coin in coins.reversed() {
        while remainingAmount >= coin {
            remainingAmount -= coin
            count += 1
        }
    }
    return count
}

minSplit(startAmount: 9)   // 5 (1, 1, 1, 1, 5)
minSplit(startAmount: 26)  // 3 (1, 5, 20)
minSplit(startAmount: 172) // 6 (1, 1, 20, 50, 50, 50)






//2. დაწერეთ ფუნქცია რომელიც დააჯამებს ციფრებს ორ რიცსხვს შორის.
//   მაგალითად გადმოგვეცემა 19 და 22. მათ შორის ციფრების ჯამი იქნება :
//   // 19, 20, 21, 22
//   // (1 + 9) + (2 + 0) + (2 + 1) + (2 + 2) = 19

func sumOfDigits(x: Int, y: Int) -> Int {
    var sum = 0
    for i in x...y {
        let newNumbers = String(i).map(
            { Int(String($0)) }
        )
        
        for newNumber in newNumbers {
            sum += newNumber!
        }
    }
    return sum
}

sumOfDigits(x: 7, y: 8)   // ➞ 15
sumOfDigits(x: 17, y: 20) // ➞ 29
sumOfDigits(x: 10, y: 12) // ➞ 6
sumOfDigits(x: 19, y: 22) // ➞ 19




//3. მოცემულია String რომელიც შედგება „(" და „)" ელემენტებისგან. დაწერეთ ფუნქცია რომელიც აბრუნებს ფრჩხილები არის თუ არა მათემატიკურად სწორად დასმული.


func isCorrectString(ourFunnyString: String) -> Bool {
    var count = 0
    for charachter in ourFunnyString {
        if charachter == "(" {
            count += 1
        } else if charachter == ")" {
            count -= 1
        }
        if count < 0 {
            return false
        }
    }
    return count == 0
}

isCorrectString(ourFunnyString: "(()())" )  // ➞ true
isCorrectString(ourFunnyString: "()(()" )    // ➞ false
isCorrectString(ourFunnyString: "(()())(" ) // ➞ false




//4. გვაქვს N ფიცრისგან შემდგარი ხიდი. სიძველის გამო ზოგიერთი ფიცარი ჩატეხილია. ზურიკოს შეუძლია გადავიდეს შემდეგ ფიცარზე ან გადაახტეს ერთ ფიცარს. (რათქმაუნდა ჩატეხილ   ფიცარზე ვერ გადავა)

//  ჩვენი ამოცანაა დავითვალოთ რამდენი განსხვავებული კომბინაციით შეუძლია ზურიკოს ხიდის გადალახვა. გადმოგვეცემა ხიდის სიგრძე და ინფორმაცია ჩატეხილ ფიცრებზე. 0 აღნიშნავს ჩატეხილ ფიცარს 1_ანი კი მთელს. დასაწყისისთვის ზურიკო დგას ხიდის ერთ მხარეს (არა პირველ ფიცარზე) და გადალახვად ჩათვლება ხიდის მეორე მხარე (ბოლო ფიცრის შემდეგი ნაბიჯი)

        
        // ძალიან ბევრი ვიწვალე, მაგრამ საბოლოო შედეგამდე ვერ მივედი :( :( 



//5. გადმოგეცემათ მთელი რიცხვი N. დაწერეთ ფუნქცია რომელიც დაითვლის რამდენი 0_ით ბოლოვდება N! (ფაქტორიალი)
//    შენიშვნა 1000! შედგება 2568 სიმბოლოსაგან.

func zeros(N: Int) -> Int {
    var count = 0
    for factor in 1...N {
        var num = factor
        while num % 5 == 0 {
            count += 1
            num /= 5
        }
    }
    return count
}

zeros(N: 5)   // ➞ 1
zeros(N: 12)  // ➞ 2
zeros(N: 490) // ➞ 120


